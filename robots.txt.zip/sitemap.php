<?php
declare(strict_types=1);

/*
 * IMPORTANT:
 * Save this file as UTF-8 WITHOUT BOM
 * File name: sitemap.php
 */

while (ob_get_level() > 0) {
    @ob_end_clean();
}

header('Content-Type: application/xml; charset=UTF-8');
error_reporting(E_ALL);
ini_set('display_errors', '0');

$baseUrl = 'https://www.buyformula.net/ar/products';

/*
 |------------------------------------------------------------
 | Database settings
 | Use the same values that worked in your db_test.php
 |------------------------------------------------------------
 */
$dbHost = 'localhost';
$dbName = 'buyform1_web';
$dbUser = 'buyform1_web';
$dbPass = 'gE9MXNgeEUut';
$prefix = 'maa';

$conn = new mysqli($dbHost, $dbUser, $dbPass, $dbName);

if ($conn->connect_error) {
    http_response_code(500);
    header('Content-Type: text/plain; charset=UTF-8');
    exit('Database connection failed.');
}

$conn->set_charset('utf8mb4');

function xmlEscape($value): string
{
    return htmlspecialchars((string)$value, ENT_XML1 | ENT_COMPAT, 'UTF-8');
}

function cleanTitle($text): string
{
    $text = html_entity_decode((string)$text, ENT_QUOTES | ENT_HTML5, 'UTF-8');
    $text = strip_tags($text);
    $text = preg_replace('/\s+/u', ' ', $text);
    return trim((string)$text);
}

function makeSlugSegment($text): string
{
    $text = cleanTitle($text);
    if ($text === '') {
        $text = 'product';
    }

    return str_replace('%20', '+', rawurlencode($text));
}

function safeDate($date): string
{
    if (empty($date)) {
        return date('Y-m-d');
    }

    $date = trim((string)$date);
    $invalidDates = [
        '0000-00-00',
        '0000-00-00 00:00:00',
        '0001-11-30',
        '0001-11-30 00:00:00',
        '1970-01-01',
        '1970-01-01 00:00:00',
    ];

    if (in_array($date, $invalidDates, true)) {
        return date('Y-m-d');
    }

    $ts = strtotime($date);
    if (!$ts || $ts <= 0) {
        return date('Y-m-d');
    }

    return date('Y-m-d', $ts);
}

echo '<?xml version="1.0" encoding="UTF-8"?>' . "\n";
echo '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9" xmlns:xhtml="http://www.w3.org/1999/xhtml">' . "\n";

$today = date('Y-m-d');

/* static URLs */
$staticUrls = [
    [$baseUrl . '/', '1.0'],
    [$baseUrl . '/ar', '0.9'],
    [$baseUrl . '/en', '0.9'],
];

foreach ($staticUrls as $item) {
    echo "  <url>\n";
    echo '    <loc>' . xmlEscape($item[0]) . "</loc>\n";
    echo "    <lastmod>{$today}</lastmod>\n";
    echo "    <changefreq>daily</changefreq>\n";
    echo '    <priority>' . $item[1] . "</priority>\n";
    echo "  </url>\n";
}

/* products */
$sql = "
    SELECT id, name_ar, name_en, date_add
    FROM {$prefix}_products
    WHERE status = 1
    ORDER BY id DESC
";

$result = $conn->query($sql);

if (!$result) {
    http_response_code(500);
    header('Content-Type: text/plain; charset=UTF-8');
    exit('Query failed.');
}

while ($row = $result->fetch_assoc()) {
    $id = (int)$row['id'];
    if ($id <= 0) {
        continue;
    }

    $nameAr = cleanTitle($row['name_ar'] ?? '');
    $nameEn = cleanTitle($row['name_en'] ?? '');

    if ($nameAr === '' && $nameEn === '') {
        $nameAr = 'product';
        $nameEn = 'product';
    } elseif ($nameAr === '') {
        $nameAr = $nameEn;
    } elseif ($nameEn === '') {
        $nameEn = $nameAr;
    }

    $slugAr = makeSlugSegment($nameAr);
    $slugEn = makeSlugSegment($nameEn);
    $lastmod = safeDate($row['date_add'] ?? '');

    $arUrl = $baseUrl . '/ar/products/View/' . $id . '/' . $slugAr;
    $enUrl = $baseUrl . '/en/products/View/' . $id . '/' . $slugEn;

    echo "  <url>\n";
    echo '    <loc>' . xmlEscape($arUrl) . "</loc>\n";
    echo "    <lastmod>{$lastmod}</lastmod>\n";
    echo "    <changefreq>weekly</changefreq>\n";
    echo "    <priority>0.8</priority>\n";
    echo '    <xhtml:link rel="alternate" hreflang="ar" href="' . xmlEscape($arUrl) . "\" />\n";
    echo '    <xhtml:link rel="alternate" hreflang="en" href="' . xmlEscape($enUrl) . "\" />\n";
    echo '    <xhtml:link rel="alternate" hreflang="x-default" href="' . xmlEscape($enUrl) . "\" />\n";
    echo "  </url>\n";

    echo "  <url>\n";
    echo '    <loc>' . xmlEscape($enUrl) . "</loc>\n";
    echo "    <lastmod>{$lastmod}</lastmod>\n";
    echo "    <changefreq>weekly</changefreq>\n";
    echo "    <priority>0.8</priority>\n";
    echo '    <xhtml:link rel="alternate" hreflang="ar" href="' . xmlEscape($arUrl) . "\" />\n";
    echo '    <xhtml:link rel="alternate" hreflang="en" href="' . xmlEscape($enUrl) . "\" />\n";
    echo '    <xhtml:link rel="alternate" hreflang="x-default" href="' . xmlEscape($enUrl) . "\" />\n";
    echo "  </url>\n";
}

echo "</urlset>";

$result->free();
$conn->close();
exit;
?>
